﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Components
{
    //This class represents an n bit register that can maintain an n bit number
    class MultiBitRegister : Gate
    {
        public WireSet Input { get; private set; }
        public WireSet Output { get; private set; }
        //A bit setting the register operation to read or write
        public Wire Load { get; private set; }

        //Word size - number of bits in the register
        public int Size { get; private set; }
        
        public SingleBitRegister[] registers{ get; private set;}


        public MultiBitRegister(int iSize)
        {
            Size = iSize;
            Input = new WireSet(Size);
            Output = new WireSet(Size);
            registers = new SingleBitRegister[Size];
            Load = new Wire();
            for (int i = 0; i < Size; i++)
            {
                registers[i] = new SingleBitRegister();
                registers[i].ConnectInput(Input[i]);
                registers[i].ConnectLoad(Load);
                Output[i].ConnectInput(registers[i].Output);
            }

        }

        public void ConnectInput(WireSet wsInput)
        {
            Input.ConnectInput(wsInput);
        }

        
        public override string ToString()
        {
            return Output.ToString();
        }


        public override bool TestGate()
        {
            Input.Set2sComplement(2);
            Load.Value = 1;
            Clock.ClockDown();
            Clock.ClockUp();
            Input.Set2sComplement(4);
            if (Output.Get2sComplement() != 2)
            {
                return false;
            }
            Load.Value = 0;
            Input.Set2sComplement(-4);
            Clock.ClockDown();
            Clock.ClockUp();
            if (Output.Get2sComplement() != 2)
            {
                return false;
            }

            Load.Value = 1;
            Input.Set2sComplement(8);
            Clock.ClockDown();
            Clock.ClockUp();
            if (Output.Get2sComplement() !=8)
            {
                return false;
            }
            
            return true;
            
        }
    }
}
