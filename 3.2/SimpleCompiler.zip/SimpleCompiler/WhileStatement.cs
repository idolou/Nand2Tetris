﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimpleCompiler
{
    public class WhileStatement : StatetmentBase
    {
        public Expression Term { get; private set; }
        public List<StatetmentBase> Body { get; private set; }
        
        //init the object list
        public WhileStatement()
        {
            Body = new List<StatetmentBase>();
        }

        public override void Parse(TokensStack sTokens)
        {
            // check for while statement
            Token tWhile = sTokens.Pop();
            if(!(tWhile is Statement) || ((Statement)tWhile).Name != "while") 
                throw new SyntaxErrorException("Expected function received: " + tWhile, tWhile);
            
            
            Token t = sTokens.Pop(); //(
            if(!(t is Parentheses) || ((Parentheses) t).Name != '(')
                throw new SyntaxErrorException("Expected open paranthesis , received " + t, t);

            //will get the term
            Expression e = Expression.Create(sTokens);
            e.Parse(sTokens);
            Term = e;
            
            t = sTokens.Pop();//)
            if(!(t is Parentheses) || ((Parentheses) t).Name != ')')
                throw new SyntaxErrorException("Expected close paranthesis , received " + t, t);
            
            t = sTokens.Pop(); //{
            if(!(t is Parentheses) || ((Parentheses) t).Name != '{')
                throw new SyntaxErrorException("Expected open paranthesis , received " + t, t);

            while (sTokens.Count > 0 && !(sTokens.Peek() is Parentheses)) //{}
            {
                
                //check if it "let", "while", "if", "else", "return" statement
                StatetmentBase baseStat = StatetmentBase.Create(sTokens.Peek());
                
                //parsing the statement
                baseStat.Parse(sTokens);
                
                //add it to the statements list
                Body.Add(baseStat);
            }
            
            t = sTokens.Pop(); //}
            if(!(t is Parentheses) || ((Parentheses) t).Name != '}')
                throw new SyntaxErrorException("Expected close parenthesis } , received " + t, t);
            
            


        }

        public override string ToString()
        {
            string sWhile = "while(" + Term + "){\n";
            foreach (StatetmentBase s in Body)
                sWhile += "\t\t\t" + s + "\n";
            sWhile += "\t\t}";
            return sWhile;
        }

    }
}
