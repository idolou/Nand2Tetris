﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimpleCompiler
{
    public class LetStatement : StatetmentBase
    {
        public string Variable { get; set; }
        public Expression Value { get; set; }

        public override string ToString()
        {
            return "let " + Variable + " = " + Value + ";";
        }

        public override void Parse(TokensStack sTokens)
        {
            // check for let statement
            Token t = sTokens.Pop();
            if(!(t is Statement) || ((Statement)t).Name != "let")
                throw new SyntaxErrorException("Expected let received: " + t, t);
            
            // get the variable
            Expression exp = Expression.Create(sTokens);
            exp.Parse(sTokens);
            Variable = exp.ToString();
            
            // check for '='
            t= sTokens.Pop();
            if(!(t is Operator) || ((Operator)t).Name != '=')
                throw new SyntaxErrorException("Expected '=' received: " + t, t);
            
            // get the value
            Expression exp1 = Expression.Create(sTokens);
            exp1.Parse(sTokens);
            Value = exp1;
            
            
            //check that finished wite ';'
            t= sTokens.Pop();
            if(!(t is Separator) || ((Separator)t).Name != ';')
                throw new SyntaxErrorException("Expected ';' received: " + t, t);

            
        }

    }
}
